*******************************
Thank you for downloading Tania
Current version: 1.7
Operating system: Linux x64
*******************************

Steps to run Tania:

1. Run it from your terminal: ./tania-core
2. Access to localhost:8080 or 127.0.0.1:8080 from your browser
3. Login with default username: tania, and password: tania

To shut Tania down you can use ctrl+c combination keys on the terminal.

Read the usage documentation on https://usetania.org/docs  
